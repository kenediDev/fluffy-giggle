yeah i'm good for today, i don't know, why i feel like because, i feel bad everyday , i hate this
